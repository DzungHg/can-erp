﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Threading.Tasks;
using Radzen;
using Radzen.Blazor;

namespace ErpCan.Pages
{
    public partial class AddTblGnGenderComponent
    {

    }
}
